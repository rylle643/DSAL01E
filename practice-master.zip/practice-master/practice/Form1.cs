﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(open.FileName);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ProgramcomboBox.Items.Add("Architecture"); ProgramcomboBox.Items.Add("Aeronautical Engineering");
            ProgramcomboBox.Items.Add("Computer Engineering"); ProgramcomboBox.Items.Add("Civil Engineering");
            ProgramcomboBox.Items.Add("Electrical Engineering");  ProgramcomboBox.Items.Add("Electronics Engineering");
            ProgramcomboBox.Items.Add("Industrial Engineering");  ProgramcomboBox.Items.Add("Mechanical Engineering");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ScholartextBox.Clear();
            CourseNolistBox.Items.Clear();
            pictureBox1.Image = null;
            ProgramcomboBox.SelectedIndex = -1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CourseNolistBox.Items.Add(CourseNumtextBox.Text);
            CourseCodelistBox.Items.Add(CourseCodetextBox.Text);
            CourseDesclistBox.Items.Add(CourseDesctextBox.Text);
            UnitLeclistBox.Items.Add(UnitLectextBox.Text);
            UnitLablistBox.Items.Add(UnitLabtextBox.Text);
            CreditUnitslistBox.Items.Add(CreditUnitstextBox.Text);
            TimelistBox.Items.Add(TimetextBox.Text);
            DaylistBox.Items.Add(DaytextBox.Text);
            TotalNoofUnits.Text = TotalNoofUnittextBox.Text;
            TotalMiscFees.Text = TotalMiscFeetextBox.Text;
            LabFees.Text = LabFeetextBox.Text;
            CiscoLabFees.Text = CiscoLabFeetextBox.Text;
            ExamBookletFees.Text = ExamBookletFeetextBox.Text;
            TotalTuitionandFees.Text = TotalTuitionandFeetextBox.Text;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            CourseCodelistBox.Items.Add(UnitLabtextBox.Text);
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox27_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
